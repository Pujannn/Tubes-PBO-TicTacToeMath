﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace tic_tac_toe_versi_saya
{
    public partial class Form1 : Form
    {
        public enum Player { X, O } // Pemain

        Player currentPlayer; // Pemain saat ini
        List<Button> buttons; // Daftar tombol permainan
        string[,] mathQuestions; // Menyimpan soal matematika
        int[,] answers; // Jawaban soal
        Random random = new Random(); // Untuk membuat soal acak
        int playerXScore = 0; // Skor pemain X
        int playerOScore = 0; // Skor pemain O
        bool isGameOver = false; // Menandakan apakah permainan selesai

        public Form1()
        {
            InitializeComponent();
            InitializeGame();

            // Event handler untuk tombol Submit dan Restart
            btnSubmit.Click += new EventHandler(btnSubmit_Click);
            btnRestart.Click += new EventHandler(btnRestart_Click);
        }

        private void InitializeGame()
        {
            // Inisialisasi daftar tombol
            buttons = new List<Button> { button1, button2, button3, button4, button5, button6, button7, button8, button9 };

            // Soal-soal matematika dan jawaban
            mathQuestions = new string[3, 3];
            answers = new int[3, 3];
            GenerateMathQuestions();

            RestartGame();
        }

        private void GenerateMathQuestions()
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    int a = random.Next(1, 10);
                    int b = random.Next(1, 10);
                    int operation = random.Next(0, 4);

                    switch (operation)
                    {
                        case 0: // Penjumlahan
                            mathQuestions[i, j] = $"{a} + {b} = ?";
                            answers[i, j] = a + b;
                            break;
                        case 1: // Pengurangan
                            mathQuestions[i, j] = $"{a} - {b} = ?";
                            answers[i, j] = a - b;
                            break;
                        case 2: // Perkalian
                            mathQuestions[i, j] = $"{a} × {b} = ?";
                            answers[i, j] = a * b;
                            break;
                        case 3: // Pembagian (hasil pembagian akan bulat)
                            a = random.Next(2, 10) * b; // Pastikan a habis dibagi b
                            mathQuestions[i, j] = $"{a} ÷ {b} = ?";
                            answers[i, j] = a / b;
                            break;
                    }
                }
            }
        }

        private void RestartGame()
        {
            // Reset tombol permainan
            foreach (Button btn in buttons)
            {
                btn.Text = "?";
                btn.Enabled = true;
                btn.BackColor = DefaultBackColor;
                btn.Tag = null; // Hapus tag lama
            }

            currentPlayer = Player.X;
            lblTurn.Text = "Player X is Turn";
            lblSoal.Text = "";
            txtJawaban.Text = "";
            isGameOver = false;
        }

        private void PlayerClickButton(object sender, EventArgs e)
        {
            if (isGameOver) return;

            Button clickedButton = sender as Button;

            if (clickedButton.Text == "?")
            {
                // Ambil posisi tombol dalam grid
                int index = buttons.IndexOf(clickedButton);
                int row = index / 3;
                int col = index % 3;

                // Tampilkan soal matematika
                lblSoal.Text = mathQuestions[row, col];
                btnSubmit.Tag = new Tuple<Button, int>(clickedButton, answers[row, col]);
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (btnSubmit.Tag is Tuple<Button, int> questionData)
            {
                Button clickedButton = questionData.Item1;
                int correctAnswer = questionData.Item2;

                if (int.TryParse(txtJawaban.Text, out int playerAnswer))
                {
                    if (playerAnswer == correctAnswer)
                    {
                        // Jawaban benar: tampilkan simbol pemain
                        clickedButton.Text = currentPlayer.ToString();
                        clickedButton.Enabled = false;
                        clickedButton.BackColor = currentPlayer == Player.X ? Color.LightGreen : Color.Pink;

                        // Periksa kondisi kemenangan
                        if (CheckWin())
                        {
                            MessageBox.Show($"Player {currentPlayer} Wins!", "Game Over");
                            UpdateScore();
                            DisableAllButtons(); // Nonaktifkan semua tombol setelah permainan berakhir
                            isGameOver = true;
                            RestartGame(); // Restart permainan
                            GenerateMathQuestions(); // Soal baru untuk permainan berikutnya
                            return; // Hentikan permainan setelah kemenangan
                        }

                        // Periksa apakah seri
                        if (IsDraw())
                        {
                            MessageBox.Show("It's a Draw!", "Game Over");
                            DisableAllButtons(); // Nonaktifkan semua tombol setelah permainan berakhir
                            isGameOver = true;
                            RestartGame(); // Restart permainan
                            GenerateMathQuestions(); // Soal baru untuk permainan berikutnya
                            return; // Hentikan permainan setelah seri
                        }

                        // Ganti pemain
                        currentPlayer = currentPlayer == Player.X ? Player.O : Player.X;
                        lblTurn.Text = $"Player {currentPlayer} is Turn";
                    }
                    else
                    {
                        MessageBox.Show("Jawaban Salah! Giliran berpindah ke pemain lain.", "Wrong Answer");
                        currentPlayer = currentPlayer == Player.X ? Player.O : Player.X;
                        lblTurn.Text = $"Player {currentPlayer} is Turn";
                    }

                    // Reset soal dan jawaban
                    lblSoal.Text = "";
                    txtJawaban.Text = "";
                }
                else
                {
                    MessageBox.Show("Masukkan angka yang valid!", "Invalid Input");
                }
            }
        }

        private bool CheckWin()
        {
            // Periksa baris, kolom, dan diagonal
            return (CheckLine(button1, button2, button3) ||
                    CheckLine(button4, button5, button6) ||
                    CheckLine(button7, button8, button9) ||
                    CheckLine(button1, button4, button7) ||
                    CheckLine(button2, button5, button8) ||
                    CheckLine(button3, button6, button9) ||
                    CheckLine(button1, button5, button9) ||
                    CheckLine(button3, button5, button7));
        }

        private bool CheckLine(Button b1, Button b2, Button b3)
        {
            return b1.Text != "?" && b1.Text == b2.Text && b2.Text == b3.Text;
        }

        private bool IsDraw()
        {
            return buttons.All(b => b.Text != "?");
        }

        private void UpdateScore()
        {
            if (currentPlayer == Player.X)
            {
                playerXScore++;
                lblScore.Text = $"Player X: {playerXScore} | Player O: {playerOScore}";
            }
            else
            {
                playerOScore++;
                lblScore.Text = $"Player X: {playerXScore} | Player O: {playerOScore}";
            }
        }

        private void DisableAllButtons()
        {
            foreach (Button btn in buttons)
            {
                btn.Enabled = false; // Nonaktifkan semua tombol setelah permainan selesai
            }
        }

        private void btnRestart_Click(object sender, EventArgs e)
        {
            RestartGame();
            GenerateMathQuestions();
        }
    }
}
